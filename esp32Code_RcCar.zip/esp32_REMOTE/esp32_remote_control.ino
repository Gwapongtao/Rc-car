/*
 WIFI: ESP32_CAR
 PASSWORD: 12345678
 PINOUT:
 GPIO27 - BACKWARD
 GPIO26 - FORWARD
 GPIO32 - LEFT
 GPIO33 - RIGHT
  VOICE COMMANDS (built from the 4 buttons)
    START / ENGINE ON   engine on: commands are accepted. The front wheels
                        do a quick left-right wiggle to show it.
    5s FORWARD          forward for 5 seconds, then stop
    FORWARD             forward until you say STOP (button stays pressed)
    5s BACKWARD         backward for 5 seconds, then stop
    BACKWARD            backward until you say STOP
    FORWARD LEFT        forward + left for 3 seconds, then stop
    FORWARD RIGHT       forward + right for 3 seconds, then stop
    BACKWARD LEFT       backward + left for 3 seconds, then stop
    BACKWARD RIGHT      backward + right for 3 seconds, then stop
    HARD LEFT FORWARD   forward + left held: drives in a circle until STOP
    HARD RIGHT FORWARD  forward + right held: circle until STOP
    STOP                releases every button: the car stops (always works)
    TURN OFF / ENGINE OFF  stops the car, wiggles the wheels left-right, then
                        ignores every command from the phone until START.
  The engine is OFF when the ESP32 starts.
*/

#include <WiFi.h>
#include <WiFiUdp.h>

// ======================= SETTINGS =======================

const char *AP_SSID     = "ESP32_CAR";   // Wi-Fi name the phone will see
const char *AP_PASSWORD = "12345678";    // at least 8 characters
const uint16_t UDP_PORT = 4210;          // must match the app

// How much of the time the drive button is pressed in the controller's
// SLOW and FAST. 100 = held down. Raise SLOW if the car stutters or
// doesn't move on Slow. Lower it if Slow is still too fast.
const int DRIVE_PERCENT[2] = { 55, 100 };   // SLOW, FAST
const char *SPEED_NAME[2]  = { "SLOW", "FAST" };
const int SLOW = 0, FAST = 1;

// One press + release cycle when pulsing, in ms. If the car jerks
// instead of driving slowly, try 60 or 200. 2.4 GHz remotes usually
// like longer cycles (150 to 250).
const unsigned long PULSE_PERIOD_MS = 120;

const unsigned long TIMED_DRIVE_MS   = 5000;  // "5s forward" / "5s backward"
const unsigned long TIMED_TURN_MS    = 3000;  // "forward left" etc.
const unsigned long WIGGLE_MS        = 300;   // engine on/off: left this long, then right
const unsigned long FAILSAFE_MS      = 600;   // release all if phone is silent this long
const unsigned long DIRECTION_GAP_MS = 150;   // pause between forward <-> backward

// ======================= WIRING TYPE =======================
// true  = DIRECT wiring: each GPIO goes straight to the "signal" side of a
//         button, and ESP32 GND is joined to the remote's V- (GND).
//         Pressed  = the GPIO pulls the button's signal to GND (OUTPUT LOW).
//         Released = the GPIO lets go completely (INPUT, high impedance).
//         Only for remotes powered by 3.3 V or less (2 x AA = 3 V).
// false = PC817 optocoupler wiring (GPIO -> 330 ohm -> PC817 pin 1).
//         Pressed = GPIO HIGH. Use this for 9 V or 4 x AA remotes.
#ifndef DIRECT_WIRING
#define DIRECT_WIRING true
#endif

// ======================= PINS =======================
const int PIN_FWD   = 26;    // remote's FORWARD button
const int PIN_BACK  = 27;    // remote's BACKWARD button
const int PIN_LEFT  = 32;    // remote's LEFT button
const int PIN_RIGHT = 33;    // remote's RIGHT button
const int PIN_LED   = 2;     // on-board blue LED: on = phone connected


// ======================= STATE =======================

enum Dir { STOPPED = 0, FORWARD = 1, BACKWARD = -1 };

WiFiUDP udp;
char packet[64];

bool engineOn = false;            // OFF until "start"
Dir driveDir = STOPPED;
int speedLevel = FAST;            // voice = FAST, controller chooses
int steer = 0;                    // -1 left, 0 straight, 1 right
unsigned long actionUntil = 0;    // a timed command ends at this time
bool actionTimed = false;         // true while a timed command runs

bool wiggling = false;            // engine on/off wheel wiggle running
unsigned long wiggleStartedAt = 0;

Dir lastPressedDir = STOPPED;     // direction whose button was last used
unsigned long driveStartedAt = 0; // start of the pulse cycle
unsigned long dirChangedAt = 0;   // for the forward <-> backward pause

unsigned long lastPacketAt = 0;
bool phoneActive = false;         // true while phone packets keep arriving
bool serialTest = false;          // true while testing from the Serial Monitor
long lastVoiceSeq = -1;
String lastVoiceReply = "";
volatile bool stationLeft = false;  // set by the Wi-Fi event

// Last level written to each pin, so we only write when it changes.
int pinLevel[40];

// ======================= BUTTONS =======================

void setButton(int pin, bool pressed) {
  int level = pressed ? 1 : 0;
  if (pinLevel[pin] == level) return;
  pinLevel[pin] = level;
#if DIRECT_WIRING
  if (pressed) {
    digitalWrite(pin, LOW);       // set the level first, then drive it:
    pinMode(pin, OUTPUT);         // the button's signal is pulled to GND
  } else {
    pinMode(pin, INPUT);          // let go: the remote's own pull-up wins
  }
#else
  digitalWrite(pin, pressed ? HIGH : LOW);   // HIGH = PC817 LED on
#endif
}

void releaseAll() {
  setButton(PIN_FWD, false);
  setButton(PIN_BACK, false);
  setButton(PIN_LEFT, false);
  setButton(PIN_RIGHT, false);
}

// Changes the drive direction. Restarts the pulse cycle so the button
// is pressed right away (no delay before the car starts).
void setDrive(Dir d) {
  if (d == driveDir) return;
  if (d != STOPPED && lastPressedDir != STOPPED && d != lastPressedDir) {
    dirChangedAt = millis();        // reversing: short pause first
  }
  driveDir = d;
  driveStartedAt = millis();
}

// Sets direction + steering. forMs = 0 means "until STOP".
void startMove(Dir d, int s, unsigned long forMs) {
  wiggling = false;
  setDrive(d);
  steer = s;
  actionTimed = forMs > 0;
  actionUntil = actionTimed ? millis() + forMs : 0;
}

// Release everything: the car stops. The engine stays as it is.
void stopMotion() {
  setDrive(STOPPED);
  steer = 0;
  actionTimed = false;
  actionUntil = 0;
  releaseAll();
}

void startWiggle() {
  wiggling = true;
  wiggleStartedAt = millis();
}

// Called every loop: works out which buttons should be pressed now.
void updateButtons() {
  unsigned long now = millis();

  if (actionTimed && (long)(now - actionUntil) >= 0) {   // timed command finished
    stopMotion();
  }

  // ---- engine on/off wiggle: left, then right, then straight ----
  if (wiggling) {
    unsigned long t = now - wiggleStartedAt;
    setButton(PIN_FWD, false);
    setButton(PIN_BACK, false);
    if (t < WIGGLE_MS) {
      setButton(PIN_RIGHT, false);
      setButton(PIN_LEFT, true);
    } else if (t < 2 * WIGGLE_MS) {
      setButton(PIN_LEFT, false);
      setButton(PIN_RIGHT, true);
    } else {
      wiggling = false;
      setButton(PIN_LEFT, false);
      setButton(PIN_RIGHT, false);
    }
    return;
  }

  // ---- drive (forward / backward) ----
  bool drivePressed = false;
  if (driveDir != STOPPED) {
    if (now - dirChangedAt < DIRECTION_GAP_MS) {
      drivePressed = false;                         // pause while reversing
      driveStartedAt = now;                         // start the cycle after the pause
    } else {
      int percent = DRIVE_PERCENT[speedLevel];
      if (percent >= 100) {
        drivePressed = true;
      } else {
        unsigned long phase = (now - driveStartedAt) % PULSE_PERIOD_MS;
        drivePressed = phase < (PULSE_PERIOD_MS * (unsigned long)percent) / 100;
      }
    }
  }
  // Release the old direction first, then press the new one, so
  // forward and backward are never pressed together.
  if (driveDir == FORWARD) {
    setButton(PIN_BACK, false);
    setButton(PIN_FWD, drivePressed);
  } else if (driveDir == BACKWARD) {
    setButton(PIN_FWD, false);
    setButton(PIN_BACK, drivePressed);
  } else {
    setButton(PIN_FWD, false);
    setButton(PIN_BACK, false);
  }
  if (drivePressed) lastPressedDir = driveDir;

  // ---- steering (left / right) ----
  if (steer < 0) {
    setButton(PIN_RIGHT, false);
    setButton(PIN_LEFT, true);
  } else if (steer > 0) {
    setButton(PIN_LEFT, false);
    setButton(PIN_RIGHT, true);
  } else {
    setButton(PIN_LEFT, false);
    setButton(PIN_RIGHT, false);
  }
}

// ======================= COMMANDS =======================

String stateText() {
  String s = driveDir == FORWARD ? "FWD" : driveDir == BACKWARD ? "BACK" : "STOP";
  s += " ";
  s += SPEED_NAME[speedLevel];
  s += steer < 0 ? " LEFT" : steer > 0 ? " RIGHT" : " STRAIGHT";
  s += engineOn ? " ON" : " OFF";
  long left = 0;
  if (actionTimed) left = ((long)(actionUntil - millis()) + 999) / 1000;
  if (left < 0) left = 0;
  s += " ";
  s += String(left);
  return s;
}

// Runs one voice command.
// Returns a short note for the Serial Monitor, "" if the command is
// unknown, or "BLOCKED" if the engine is off.
String runVoiceCommand(const String &cmd) {
  // These always work, engine on or off.
  if (cmd == "STOP") { stopMotion(); return "stop"; }
  if (cmd == "START") {
    if (engineOn) return "engine already on";
    stopMotion();
    engineOn = true;
    startWiggle();
    return "engine ON";
  }
  if (cmd == "OFF") {
    stopMotion();
    if (!engineOn) return "engine already off";
    engineOn = false;
    startWiggle();
    return "engine OFF, commands blocked";
  }

  bool known = cmd == "FWD" || cmd == "BACK" || cmd == "FWD5" || cmd == "BACK5" ||
               cmd == "FWD_LEFT" || cmd == "FWD_RIGHT" || cmd == "BACK_LEFT" ||
               cmd == "BACK_RIGHT" || cmd == "HARD_LEFT" || cmd == "HARD_RIGHT";
  if (!known) return "";
  if (!engineOn) return "BLOCKED";

  speedLevel = FAST;                       // voice = button held down
  if (cmd == "FWD")        { startMove(FORWARD, 0, 0);               return "forward until STOP"; }
  if (cmd == "BACK")       { startMove(BACKWARD, 0, 0);              return "backward until STOP"; }
  if (cmd == "FWD5")       { startMove(FORWARD, 0, TIMED_DRIVE_MS);  return "forward 5 s"; }
  if (cmd == "BACK5")      { startMove(BACKWARD, 0, TIMED_DRIVE_MS); return "backward 5 s"; }
  if (cmd == "FWD_LEFT")   { startMove(FORWARD, -1, TIMED_TURN_MS);  return "forward left 3 s"; }
  if (cmd == "FWD_RIGHT")  { startMove(FORWARD, 1, TIMED_TURN_MS);   return "forward right 3 s"; }
  if (cmd == "BACK_LEFT")  { startMove(BACKWARD, -1, TIMED_TURN_MS); return "backward left 3 s"; }
  if (cmd == "BACK_RIGHT") { startMove(BACKWARD, 1, TIMED_TURN_MS);  return "backward right 3 s"; }
  if (cmd == "HARD_LEFT")  { startMove(FORWARD, -1, 0);              return "circle left until STOP"; }
  startMove(FORWARD, 1, 0);                                          // HARD_RIGHT
  return "circle right until STOP";
}

// "M F L 1": controller mode, the full state in every packet.
void runControllerPacket(const String &msg) {
  if (msg.length() < 7) return;
  if (!engineOn || wiggling) return;      // engine off: arrows do nothing
  char d = msg.charAt(2), s = msg.charAt(4), v = msg.charAt(6);
  speedLevel = (v == '0') ? SLOW : FAST;
  startMove(d == 'F' ? FORWARD : d == 'B' ? BACKWARD : STOPPED,
            s == 'L' ? -1 : s == 'R' ? 1 : 0, 0);   // hold while the arrow is held
  updateButtons();                                  // let go = release right now
}

void reply(const String &text) {
  udp.beginPacket(udp.remoteIP(), udp.remotePort());
  udp.print(text);
  udp.endPacket();
}

void handleUdp() {
  int size = udp.parsePacket();
  if (size <= 0) return;
  int len = udp.read(packet, sizeof(packet) - 1);
  if (len <= 0) return;
  packet[len] = '\0';

  String msg = String(packet);
  msg.trim();
  msg.toUpperCase();

  lastPacketAt = millis();
  if (!phoneActive) {
    Serial.println("Phone connected");
    lastVoiceSeq = -1;                     // a restarted app counts from new numbers
  }
  phoneActive = true;
  serialTest = false;
  digitalWrite(PIN_LED, HIGH);

  if (msg == "PING") { reply("PONG"); return; }
  if (msg == "HB")   { reply("ST " + stateText()); return; }

  if (msg.startsWith("M ")) {
    runControllerPacket(msg);
    reply("ST " + stateText());
    return;
  }

  if (msg.startsWith("V ")) {              // "V 17 FWD5"
    int space = msg.indexOf(' ', 2);
    if (space < 0) { reply("UNKNOWN"); return; }
    long seq = msg.substring(2, space).toInt();
    String cmd = msg.substring(space + 1);

    // The app re-sends if the answer gets lost. Don't run it twice.
    if (seq == lastVoiceSeq) { reply(lastVoiceReply); return; }

    String note = runVoiceCommand(cmd);
    if (note == "") { reply("UNKNOWN " + cmd); return; }
    lastVoiceSeq = seq;
    String head = note == "BLOCKED" ? "BLOCKED " : "OK ";
    updateButtons();
    lastVoiceReply = head + String(seq) + " " + cmd + " " + stateText();
    reply(lastVoiceReply);
    Serial.println("Voice: " + cmd + " -> " + (note == "BLOCKED" ? String("ignored, engine is OFF") : note));
    return;
  }

  reply("UNKNOWN");
}

// Presses each button for 0.5 s, one after the other, so you can check
// the wiring. Watch the car's wheels (lift the car first!).
void wiringTest() {
  struct { int pin; const char *name; } buttons[] = {
    { PIN_FWD, "FORWARD" }, { PIN_BACK, "BACKWARD" },
    { PIN_LEFT, "LEFT" },   { PIN_RIGHT, "RIGHT" },
  };
  stopMotion();
  wiggling = false;
  for (auto &b : buttons) {
    Serial.print("Pressing ");
    Serial.print(b.name);
    Serial.print(" (GPIO ");
    Serial.print(b.pin);
    Serial.println(")");
    setButton(b.pin, true);
    delay(500);
    setButton(b.pin, false);
    delay(500);
  }
  Serial.println("Wiring test done.");
}

// Type a command in the Serial Monitor to test without the phone
// (lift the car first!): START, FWD, FWD5, BACK, BACK5, FWD_LEFT,
// FWD_RIGHT, BACK_LEFT, BACK_RIGHT, HARD_LEFT, HARD_RIGHT, STOP, OFF, TEST
void handleSerial() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  cmd.toUpperCase();
  if (cmd == "") return;
  if (cmd == "TEST") { serialTest = false; wiringTest(); return; }
  String note = runVoiceCommand(cmd);
  if (note == "") {
    Serial.println("Unknown. Try START FWD FWD5 BACK BACK5 FWD_LEFT FWD_RIGHT BACK_LEFT "
                   "BACK_RIGHT HARD_LEFT HARD_RIGHT STOP OFF TEST");
    return;
  }
  if (note == "BLOCKED") note = "ignored, engine is OFF. Type START first";
  serialTest = driveDir != STOPPED;        // failsafe is paused while testing from the PC
  Serial.println("Test: " + note + "  -> " + stateText());
}

// ======================= FAILSAFE =======================

void onWifiEvent(WiFiEvent_t event) {
  if (event == ARDUINO_EVENT_WIFI_AP_STADISCONNECTED) stationLeft = true;
}

void checkFailsafe() {
  if (stationLeft) {                       // phone left the Wi-Fi
    stationLeft = false;
    if (!serialTest) {
      stopMotion();
      wiggling = false;
      phoneActive = false;
      digitalWrite(PIN_LED, LOW);
      Serial.println("FAILSAFE: phone left the Wi-Fi, all buttons released");
    }
  }
  if (phoneActive && millis() - lastPacketAt > FAILSAFE_MS) {
    phoneActive = false;
    digitalWrite(PIN_LED, LOW);
    if (!serialTest) {
      stopMotion();
      wiggling = false;
      Serial.println("FAILSAFE: no signal from phone, all buttons released");
    }
  }
}

// ======================= SETUP / LOOP =======================

void setup() {
  // Release every button first, so nothing is pressed while starting.
  for (int i = 0; i < 40; i++) pinLevel[i] = -1;
  const int outs[] = { PIN_FWD, PIN_BACK, PIN_LEFT, PIN_RIGHT };
  for (int pin : outs) {
#if DIRECT_WIRING
    pinMode(pin, INPUT);          // released = not driven at all
#else
    digitalWrite(pin, LOW);       // released = PC817 LED off
    pinMode(pin, OUTPUT);
#endif
    setButton(pin, false);
  }
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  Serial.begin(115200);
  Serial.setTimeout(20);

  WiFi.onEvent(onWifiEvent);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  WiFi.setSleep(false);                    // lowest latency
  udp.begin(UDP_PORT);

  Serial.print("Wi-Fi \"");
  Serial.print(AP_SSID);
  Serial.print("\" started at ");
  Serial.print(WiFi.softAPIP());
  Serial.print(", UDP port ");
  Serial.println(UDP_PORT);
  Serial.println(DIRECT_WIRING ? "Wiring: DIRECT (pressed = pin to GND)" : "Wiring: PC817 optocouplers (pressed = pin HIGH)");
  Serial.println("Remote buttons: FWD=26 BACK=27 LEFT=32 RIGHT=33. Engine is OFF.");
  Serial.println("Type START, then FWD5, STOP, OFF ... or TEST to check the wiring.");
}

void loop() {
  handleUdp();
  handleSerial();
  checkFailsafe();
  updateButtons();
}
